<?php
// Menangkap data JSON yang dikirim dari client
$data = json_decode(file_get_contents("php://input"), true);

// Menyiapkan respon
$response = [];

// Daftar penyakit umum yang tidak memerlukan rujukan
$penyakitUmum = [
    'batuk', 'pilek', 'demam', 'diare', 'sakit kepala', 'sakit tenggorokan'
];

// Memeriksa apakah data yang diterima lengkap dan valid
if (isset($data['no_bpjs'], $data['nama_pasien'], $data['tgl_lahir'], $data['diagnosa'], $data['alasan'], $data['tujuan'])) {
    // Mengubah diagnosa menjadi huruf kecil agar tidak ada masalah dengan kapitalisasi
    $diagnosa = strtolower($data['diagnosa']);

    // Memeriksa apakah diagnosa termasuk dalam daftar penyakit umum
    if (in_array($diagnosa, $penyakitUmum)) {
        // Jika diagnosa termasuk penyakit umum, kirimkan status gagal
        $response = [
            'status' => 'failed',
            'message' => 'Rujukan ditolak, penyakit yang dilaporkan termasuk kategori penyakit umum.'
        ];
    } else {
        // Proses pengajuan rujukan, jika diagnosa tidak termasuk penyakit umum
        $response = [
            'status' => 'success',
            'rujukan' => $data
        ];
    }
} else {
    // Jika data tidak lengkap
    $response = [
        'status' => 'failed',
        'message' => 'Data tidak lengkap. Harap lengkapi form pengajuan rujukan.'
    ];
}

// Mengirimkan respons dalam format JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
