document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('rujukanForm').onsubmit = function(event) {
        event.preventDefault(); // Menghindari form submit default

        let formData = {
            no_bpjs: document.getElementById('no_bpjs').value,
            nama_pasien: document.getElementById('nama_pasien').value,
            tgl_lahir: document.getElementById('tgl_lahir').value,
            diagnosa: document.getElementById('diagnosa').value,
            alasan: document.getElementById('alasan').value,
            tujuan: document.getElementById('tujuan').value
        };

        // Mengirim data ke server.php menggunakan AJAX
        fetch('server.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                // Menampilkan detail rujukan jika berhasil
                let html = `
                    <strong>Detail Rujukan:</strong><br>
                    Nomor BPJS: ${data.rujukan.no_bpjs}<br>
                    Nama Pasien: ${data.rujukan.nama_pasien}<br>
                    Tanggal Lahir: ${data.rujukan.tgl_lahir}<br>
                    Diagnosa: ${data.rujukan.diagnosa}<br>
                    Alasan: ${data.rujukan.alasan}<br>
                    Tujuan: ${data.rujukan.tujuan}<br>
                `;
                document.getElementById('statusRujukan').innerHTML = html;
            } else {
                // Menampilkan pesan gagal jika proses rujukan ditolak
                document.getElementById('statusRujukan').textContent = "Proses rujukan ditolak karena penyakit yang di diagnosa termasuk kategori penyakit umum.";
            }
        })
        .catch(error => {
            document.getElementById('statusRujukan').textContent = 'Terjadi kesalahan, coba lagi.';
        });
    };
});
