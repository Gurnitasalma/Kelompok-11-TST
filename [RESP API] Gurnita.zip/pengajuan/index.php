<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pengajuan Rujukan</title>
    <script src="client.js"></script>
    <link rel="stylesheet" href="styles.css">

</head>
<body>

    <h1>Form Pengajuan Rujukan</h1>

    <form id="rujukanForm">
        <label for="no_bpjs">Nomor BPJS:</label>
        <input type="text" id="no_bpjs" name="no_bpjs" required><br>

        <label for="nama_pasien">Nama Pasien:</label>
        <input type="text" id="nama_pasien" name="nama_pasien" required><br>

        <label for="tgl_lahir">Tanggal Lahir:</label>
        <input type="date" id="tgl_lahir" name="tgl_lahir" required><br>

        <label for="diagnosa">Diagnosa Penyakit:</label>
        <input type="text" id="diagnosa" name="diagnosa" required><br>

        <label for="alasan">Alasan Rujukan:</label>
        <input type="text" id="alasan" name="alasan" required><br>

        <label for="tujuan">Tujuan RS Rujukan:</label>
        <input type="text" id="tujuan" name="tujuan" required><br>

        <input type="submit" value="Kirim Rujukan">
    </form>

    <h2 id="statusRujukan"></h2>

</body>
</html>
