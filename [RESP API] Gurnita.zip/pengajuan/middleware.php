<?php

function validateRujukan($data) {
    // Melakukan validasi data
    if (empty($data['no_bpjs']) || empty($data['nama_pasien']) || empty($data['diagnosa']) || empty($data['alasan']) || empty($data['tujuan'])) {
        return ['status' => false, 'message' => 'Data tidak lengkap.'];
    }
    return ['status' => true, 'message' => 'Data valid.'];
}

// Mengambil data dari client
$data = json_decode(file_get_contents('php://input'), true);

// Validasi data
$validation = validateRujukan($data);
echo json_encode($validation);
?>
