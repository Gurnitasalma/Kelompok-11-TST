<?php
class BPJSVerification  {
    public function verifyBPJS($parameters) {
        $nomorBPJS = $parameters->nomorBPJS;

        // Dummy data nomor BPJS yang valid
        $validBPJS = [
            "1234567890" => "Kelas 1",
            "0987654321" => "Kelas 2"
        ];

        $response = new stdClass();
        if (isset($validBPJS[$nomorBPJS])) {
            $response->status = 'success';
            $response->message = 'Verifikasi berhasil';
            $response->kelasPerawatan = $validBPJS[$nomorBPJS];
        } else {
            $response->status = 'failed';
            $response->message = 'Nomor BPJS tidak valid';
            $response->kelasPerawatan = 'Tidak tersedia';
        }

        return $response;
    }
}
?>
