<?php
require_once 'client.php';
$wsdl = "bpjs.wsdl";


header('Content-Type: application/json');

// Cek apakah input datang dari JSON (Postman) atau query string (Browser)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Input dari POST (Postman atau form)
    $data = json_decode(file_get_contents("php://input"), true);
    $nomorBPJS = $data['nomorBPJS'] ?? null;
} else {
    // Input dari GET (Browser)
    $nomorBPJS = $_GET['nomorBPJS'] ?? null;
}

if (!$nomorBPJS) {
    echo json_encode(['status' => 'error', 'message' => 'Nomor BPJS harus diisi!']);
    exit;
}

try {
    // Panggil fungsi verifyBPJS dari SOAP Client
    $result = verifyBPJS($nomorBPJS);

    // Format respons JSON
    echo json_encode([
        'status' => $result->status ?? 'error',
        'message' => $result->message ?? 'Terjadi kesalahan',
        'kelas' => $result->kelasPerawatan ?? 'Tidak tersedia'
    ]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
