<?php
ini_set('soap.wsdl_cache_enabled', 0);
ini_set('soap.wsdl_cache_ttl', 0);

$wsdl = 'http://localhost/ProyekTST/bpjs.wsdl'; 

try {
    $client = new SoapClient($wsdl);

    function verifyBPJS($bpjsNumber) {
        global $client;

        $params = [
            'nomorBPJS' => $bpjsNumber
        ];

        $response = $client->__soapCall('verifyBPJS', [$params]);
        return $response;
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'SOAP Error: ' . $e->getMessage()]);
    exit;
}
?>
