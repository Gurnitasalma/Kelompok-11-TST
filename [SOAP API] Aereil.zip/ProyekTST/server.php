<?php
require_once 'BPJSVerification.php';
header('Content-Type: text/plain');

try {
    // Inisialisasi SOAP Server dengan WSDL
    $server = new SoapServer('bpjs.wsdl');
    $server->setClass('BPJSVerification');
    $server->handle();
} catch (SOAPFault $e) {
    error_log($e->getMessage());
}
?>
