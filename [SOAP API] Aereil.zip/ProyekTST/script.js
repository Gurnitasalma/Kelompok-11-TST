$(document).ready(function () {
    console.log('Document ready!'); // Log untuk memastikan script.js aktif

    $('#verifyButton').on('click', function () {
        console.log('Tombol diklik!'); // Log klik tombol

        const bpjsNumber = $('#bpjsNumber').val();
        console.log('Nomor BPJS:', bpjsNumber);

        if (!bpjsNumber) {
            alert('Nomor BPJS harus diisi!');
            return;
        }

        // Kirim data ke server
        $.ajax({
            url: 'verifyBPJS.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ nomorBPJS: bpjsNumber }),
            success: function (response) {
                console.log('Respons server:', response);
                $('#status').text(`Status: ${response.status}`);
                $('#message').text(`Pesan: ${response.message}`);
                $('#kelas').text(`Hak Kelas Perawatan: ${response.kelas || 'Tidak tersedia'}`);
            },
            error: function () {
                console.log('AJAX error');
                alert('Gagal menghubungi server.');
            }
        });
    });
});
