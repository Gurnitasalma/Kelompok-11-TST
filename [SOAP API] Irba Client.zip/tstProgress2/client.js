// $(document).ready(function() {
//   $('#submit-claim').on('click', function() {
//       // Ambil ID BPJS dari input
//       let klaimId = $('#klaimId').val();
      
//       $.ajax({
//           url: 'proxy.php',
//           method: 'GET',
//           data: { 
//               bpjsId: klaimId,  // Kirim ID BPJS yang dimasukkan
//               status: 'aktif'    // Atau gunakan status sesuai kondisi
//           }
//       }).done(function(result) {
//           if (result.error) {
//               $('#result').html('<p>Kesalahan: ' + result.error + '</p>');
//           } else {
//               let html = '<p>Status Klaim BPJS: ' + result.status_klaim + '</p>';
//               $('#result').html(html);
//           }
//       }).fail(function(xhr, status, error) {
//           $('#result').html('<p>Kesalahan: ' + error + '</p>');
//       });
//   });
// });

// $(document).ready(function() {

//   // Ketika tombol 'Ajukan Klaim' diklik
//   $('#submit-claim').on('click', function() {
//     // Kirim permintaan AJAX ke middleware (proxy.php)
//     $.ajax({
//       url: 'proxy.php',  // Kirim permintaan ke skrip proxy
//       method: 'GET',
//       data: { status: 'aktif' }  // Parameter status bisa 'aktif' atau 'tidak aktif'
//     }).done(function(result) {
//       // Periksa apakah ada error dalam respons
//       if (result.error) {
//         $('#result').html('<p>Kesalahan: ' + result.error + '</p>');
//       } else {
//         let html = '<p>Status Klaim BPJS: ' + result.status_klaim + '</p>';
//         $('#result').html(html); // Tampilkan hasil di div 'result'
//       }
//     }).fail(function(xhr, status, error) {
//       // Menangani error AJAX
//       $('#result').html('<p>Kesalahan: ' + error + '</p>');
//     });
//   });

  
// });
// // Ketika tombol 'Get Claim History' diklik (jika ingin menambahkan fungsionalitas riwayat klaim)
  // $('#get-history').on('click', function() {
  //   $.ajax({
  //     url: 'client-history.php', // Menambahkan PHP untuk menangani riwayat klaim jika diperlukan
  //     method: 'POST'
  //   }).done(function(result) {
  //     let html = '';
  //     for (let his of result) {
  //       html += `<p>${his.date} - ${his.location} - ${his.attendants}</p>`;
  //     }
  //     $('#result').html(html); // Tampilkan riwayat klaim di div 'result'
  //   }).fail(function(xhr, status, error) {
  //     // Menangani error AJAX
  //     $('#result').html('<p>Kesalahan: ' + error + '</p>');
  //   });
  // });
