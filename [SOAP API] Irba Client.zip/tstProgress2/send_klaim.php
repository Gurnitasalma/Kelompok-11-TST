
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set the response header to JSON
header('Content-Type: application/json');

// Database connection parameters
$host = '127.0.0.1:3307';
$db = 'bpjs_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';


// Create a PDO instance for database connection
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // Return error response if connection fails
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}

// Retrieve the JSON data from the POST request
$inputData = json_decode(file_get_contents('php://input'), true);

// Validate the input data
if (isset($inputData['bpjs_id']) && !empty($inputData['bpjs_id'])) {
    $bpjsId = $inputData['bpjs_id'];

    $stmt = $pdo->prepare("SELECT * FROM ajukan_klaim WHERE bpjs_id = :bpjs_id AND status_bpjs = 'aktif'");
    $stmt->execute(['bpjs_id' => $bpjsId]);
    $existingClaim = $stmt->fetch();

    if ($existingClaim) {
        $stmt = $pdo->prepare("INSERT INTO ajukan_klaim (bpjs_id, nama) VALUES (:bpjs_id, :nama)");
        $stmt->execute(['bpjs_id' => $bpjsId, 'nama' => $nama]);
        echo json_encode(['success' => true, 'message' => 'Klaim berhasil diajukan.']);
    } else {
        echo json_encode(['success' => false, 'error' => 'ID BPJS tidak aktif.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Data tidak valid.']);
}

?>
