<!-- <?php

$wsdl = 'http://localhost/projectTST/bpjs.wsdl'; // Lokasi file WSDL

// Membuat SOAP client
$client = new SoapClient($wsdl);


// Mengambil parameter status dan ID BPJS dari request
$status = $_REQUEST['status'] ?? 'aktif'; // Default ke 'aktif' jika tidak ada
$bpjsId = $_REQUEST['bpjsId'] ?? null; // Mengambil ID BPJS dari request (dianggap dikirim melalui parameter)

// Jika ID BPJS tidak ada di request, tampilkan error
if ($bpjsId === null) {
    echo json_encode(['error' => 'ID BPJS tidak ditemukan.']);
    exit;
}

// Koneksi ke database
$host = '127.0.0.1:3307';
$db = 'bpjs_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo json_encode(['error' => 'Tidak dapat terhubung ke database: ' . $e->getMessage()]);
    exit;
}

// Cek apakah ID BPJS ada di database
$stmt = $pdo->prepare("SELECT status_bpjs FROM ajukan_klaim WHERE bpjs_id = :bpjsId");
$stmt->execute(['bpjsId' => $bpjsId]);
$row = $stmt->fetch();

// Jika ID BPJS tidak ditemukan
if (!$row) {
    echo json_encode(['error' => 'Pasien tidak terdaftar']);
    exit;
}

// Cek status BPJS pasien
$statusBPJS = $row['status_bpjs'];

// Tentukan klaim apakah disetujui atau ditolak berdasarkan status BPJS
if ($statusBPJS === 'aktif') {
    $klaimStatus = 'Klaim disetujui';
} else {
    $klaimStatus = 'Klaim ditolak';
}

// Jika status BPJS aktif, panggil SOAP service untuk mendapatkan informasi BPJS lebih lanjut
if ($statusBPJS === 'aktif') {
    try {
        // Panggil metode getBPJS dari SOAP service
        $response = $client->getBPJS($bpjsId, $status);

        // Mengembalikan respons dari SOAP service
        $responseData = [
            'klaim_status' => $klaimStatus,
            'bpjs_info' => $response
        ];

        echo json_encode($responseData);

    } catch (SoapFault $e) {
        echo json_encode(['error' => 'Gagal mengambil data dari server BPJS: ' . $e->getMessage()]);
    }
} else {
    // Jika status BPJS tidak aktif, tampilkan klaim ditolak
    echo json_encode(['klaim_status' => $klaimStatus]);
}

?> -->
