

<!-- 
// //Ambil parameter status dari permintaan klien
// $status = $_REQUEST['status'] ?? 'aktif'; // Default ke 'aktif' jika status tidak diberikan

// // Lokasi file WSDL untuk SOAP service
// $wsdl = 'http://localhost/projectTST/bpjs.wsdl'; 

// try {
//     // Membuat SOAP client dan mengarahkannya ke lokasi WSDL
//     $client = new SoapClient($wsdl);
    
//     // Panggil method 'getBPJS' dari SOAP service
//     $response = $client->getBPJS($status);
    
//     // Set content-type ke JSON untuk konsumsi oleh klien
//     header('Content-Type: application/json');
    
//     // Kembalikan respons sebagai string yang di-encode dalam format JSON
//     echo json_encode($response);
    
// } catch (SoapFault $e) {
//     // Menangani error dari SOAP service
//     header('Content-Type: application/json');
//     echo json_encode(['error' => 'Gagal terhubung ke SOAP service: ' . $e->getMessage()]);
// }
// ?> -->
