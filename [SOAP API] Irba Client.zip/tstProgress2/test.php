<?php
try {
    $client = new SoapClient("http://localhost/projectTST/bpjs.wsdl");
    echo "SOAP client berhasil dibuat!";
} catch (SoapFault $e) {
    echo "SOAP Error: " . $e->getMessage();
}
