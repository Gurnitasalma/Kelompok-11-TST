<?php
require "bpjs.php";

if (!file_exists('bpjs.wsdl')) {
    die("WSDL file not found. Generate it first using genwsdl.php.");
}

$server = new SoapServer('bpjs.wsdl');
$server->setClass('klaimBPJS');
$server->handle();
