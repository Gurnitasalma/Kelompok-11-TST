<?php
if (file_exists("http://localhost/projectTST/bpjs.wsdl")) {
    echo "File WSDL ditemukan.";
} else {
    echo "File WSDL tidak ditemukan.";
}

?>
