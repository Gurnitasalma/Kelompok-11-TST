<?php
require "vendor/autoload.php";
require "bpjs.php";

$gen = new \PHP2WSDL\PHPClass2WSDL("klaimBPJS", "http://localhost/projectTST/server.php");
$gen->generateWSDL();
file_put_contents("bpjs.wsdl", $gen->dump());
echo "WSDL generated successfully!";
