<?php
class klaimBPJS {
    private $host = '127.0.0.1'; // Host database
    private $port = '3306'; // Port MySQL (default 3306)
    private $username = 'root'; // Username MySQL
    private $password = ''; // Password MySQL
    private $database = 'bpjs_db'; // Nama database
    private $conn; // Koneksi database

    /**
     * Koneksi ke database
     */
    private function connectDB() {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database, $this->port);
        if ($this->conn->connect_error) {
            throw new Exception('Koneksi database gagal: ' . $this->conn->connect_error);
        }
    }

    /**
     * Mendapatkan status klaim BPJS berdasarkan ID dan status
     * @param string $bpjsId ID BPJS pasien
     * @param string $status Status BPJS (aktif/tidak aktif)
     * @return array Status klaim dan pesan
     */
    public function getBPJS($bpjsId, $status) {
        $this->connectDB();

        $klaim1 = "Disetujui";
        $klaim2 = "Ditolak";
        $statusKlaim = "";

        // Menentukan status klaim
        if ($status === "aktif") {
            $statusKlaim = $klaim1;
        } else if ($status === "tidak aktif") {
            $statusKlaim = $klaim2;
        }

        // Query untuk mendapatkan data BPJS berdasarkan ID
        $sql = "SELECT id, nama, status_bpjs FROM ajukanKlaim WHERE id = ? LIMIT 1";
        $stmt = $this->conn->prepare($sql);

        if (!$stmt) {
            throw new Exception("Kesalahan query: " . $this->conn->error);
        }

        $stmt->bind_param("s", $bpjsId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($dataPasien = $result->fetch_assoc()) {
            if ($dataPasien['status_bpjs'] === $status) {
                $message = "Klaim berhasil diproses.";
            } else {
                $message = "Status BPJS tidak sesuai dengan klaim.";
            }
        } else {
            $statusKlaim = "Tidak Ditemukan";
            $message = "ID BPJS tidak ditemukan.";
        }

        // Menutup koneksi
        $stmt->close();
        $this->conn->close();

        return ['status_klaim' => $statusKlaim, 'message' => $message];
    }

    /**
     * Mendapatkan semua data BPJS
     * @return array Data pasien BPJS
     */
    public function getAllBPJS() {
        $this->connectDB();

        $sql = "SELECT id, nama, status_bpjs FROM ajukanKlaim";
        $result = $this->conn->query($sql);

        if (!$result) {
            throw new Exception("Kesalahan query: " . $this->conn->error);
        }

        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        // Menutup koneksi
        $this->conn->close();

        return $data;
    }
}
